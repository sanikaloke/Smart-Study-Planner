<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>AI Study Guide Generator</title>
  <style>
    body {
      font-family: 'Segoe UI', sans-serif;
      background: #f2f2f2;
      padding: 30px;
    }

    .container {
      max-width: 700px;
      margin: auto;
      background: white;
      padding: 25px;
      border-radius: 10px;
      box-shadow: 0 0 15px rgba(0,0,0,0.1);
    }

    h2 {
      text-align: center;
    }

    textarea, select {
      width: 100%;
      margin: 10px 0;
      padding: 10px;
      border: 1px solid #ddd;
      border-radius: 5px;
      font-size: 1rem;
    }

    button {
      padding: 10px 20px;
      background-color: #4CAF50;
      border: none;
      color: white;
      border-radius: 5px;
      cursor: pointer;
    }

    .result {
      margin-top: 20px;
      padding: 15px;
      background-color: #e8f5e9;
      border-left: 5px solid #4CAF50;
      border-radius: 5px;
      white-space: pre-wrap;
    }
  </style>
</head>
<body>
  <div class="container">
    <h2>📘 AI-Generated Study Guide</h2>

    <textarea id="userInput" rows="6" placeholder="Enter topic or paste notes..."></textarea>

    <select id="outputType">
      <option value="summary">📑 Chapter Summary</option>
      <option value="visual">📊 Visual Outline</option>
      <option value="overview">🧠 Comprehensive Overview</option>
    </select>

    <button onclick="generateGuide()">Generate with AI</button>

    <div class="result" id="outputBox" style="display: none;"></div>
  </div>

  <script>
    async function generateGuide() {
      const userInput = document.getElementById('userInput').value.trim();
      const type = document.getElementById('outputType').value;
      const outputBox = document.getElementById('outputBox');

      if (!userInput) {
        outputBox.innerText = "Please enter a topic or notes.";
        outputBox.style.display = "block";
        return;
      }

      outputBox.innerText = "Generating with AI, please wait...";
      outputBox.style.display = "block";

      const response = await fetch('generate.php', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({ input: userInput, type: type })
      });

      const data = await response.json();
      outputBox.innerText = data.result || "Something went wrong.";
    }
  </script>
</body>
</html>
