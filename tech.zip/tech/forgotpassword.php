<?php
// Include PHPMailer
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer/PHPMailer.php';
require 'PHPMailer/SMTP.php';
require 'PHPMailer/Exception.php';

// Database connection
include "db.php";

$message = ""; // Variable to store messages

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    if (!isset($_POST['email']) || empty(trim($_POST['email']))) {
        $message = "<p class='error'>Please enter a valid email address.</p>";
    } else {
        $email = trim($_POST['email']);

        // Check if email exists in the database
        $stmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows > 0) {
            // Generate reset token and expiry time
            $reset_token = bin2hex(random_bytes(32));
            $token_expiry = date("Y-m-d H:i:s", strtotime('+2 hour'));

            // Store token in database
            $stmt = $conn->prepare("UPDATE users SET reset_token = ?, reset_expiry = ? WHERE email = ?");
            $stmt->bind_param("sss", $reset_token, $token_expiry, $email);
            $stmt->execute();

            if ($stmt->affected_rows > 0) {
                $mail = new PHPMailer(true);
                try {
                    $mail->isSMTP();
                    $mail->Host = 'smtp.gmail.com';
                    $mail->SMTPAuth = true;
                    $mail->Username = 'mindmap542@gmail.com'; // Replace with your email
                    $mail->Password = 'cwpp tkhs aaxf akrz'; // Replace with your App Password
                    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
                    $mail->Port = 587;

                    $mail->setFrom('mindmap542@gmail.com', 'MindMap');
                    $mail->addAddress($email);

                    $mail->isHTML(true);
                    $mail->Subject = 'Password Reset';
                    $mail->Body = "Click <a href='http://localhost/CodHer/resetpassword.php?token=$reset_token'>here</a> to reset your password.";

                    if ($mail->send()) {
                        $message = "<p class='success'>Reset link sent to your email.</p>";
                    } else {
                        $message = "<p class='error'>Failed to send email.</p>";
                    }
                } catch (Exception $e) {
                    $message = "<p class='error'>Mailer Error: " . htmlspecialchars($mail->ErrorInfo) . "</p>";
                }
            } else {
                $message = "<p class='error'>Failed to update reset token.</p>";
            }
        } else {
            $message = "<p class='error'>Email not found!</p>";
        }

        $stmt->close();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forgot Password</title>
    <link rel="stylesheet" href="login.css">
</head>
<body>
<div class="container">
    <h2>Forgot Password</h2>
    <p>Enter your email to receive a reset link.</p>
    <form action="forgotpassword.php" method="POST">
        <label for="email">Email Address</label>
        <input type="email" id="email" name="email" placeholder="you@example.com" required>
        <button type="submit">Send Reset Link</button>
    </form>

    <div class="back-to-login">
        <a href="login.php">Back to Login</a>
    </div>
</div>



    <?php if (!empty($message)) echo $message; ?> <!-- Display messages -->
</body>
</html>
