<?php
// Replace this with your actual OpenAI API key
$apiKey = 'YOUR_OPENAI_API_KEY_HERE';

header('Content-Type: application/json');

$inputData = json_decode(file_get_contents("php://input"), true);
$input = trim($inputData['input'] ?? '');
$type = $inputData['type'] ?? 'summary';

if (!$input) {
    echo json_encode(['result' => 'No input received.']);
    exit;
}

// Set prompt based on selected type
switch ($type) {
    case 'summary':
        $prompt = "Create a short study guide summary for the topic: \"$input\".";
        break;
    case 'visual':
        $prompt = "Create a visual-style outline (in text format) for the topic: \"$input\" with bullet points and hierarchy.";
        break;
    case 'overview':
        $prompt = "Give a detailed, comprehensive study guide overview for: \"$input\" including key points, explanation, and summary.";
        break;
    default:
        $prompt = "Generate a study guide for: \"$input\".";
}

// Prepare OpenAI API request
$postData = [
    'model' => 'gpt-3.5-turbo',
    'messages' => [
        ['role' => 'system', 'content' => 'You are an AI tutor that creates helpful study guides.'],
        ['role' => 'user', 'content' => $prompt]
    ],
    'temperature' => 0.7
];

$ch = curl_init('https://api.openai.com/v1/chat/completions');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'Content-Type: application/json',
    'Authorization: Bearer ' . $apiKey
]);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($postData));

$response = curl_exec($ch);

if (curl_errno($ch)) {
    echo json_encode(['result' => 'Curl error: ' . curl_error($ch)]);
    exit;
}

curl_close($ch);

$data = json_decode($response, true);

$result = $data['choices'][0]['message']['content'] ?? 'No response from OpenAI.';

echo json_encode(['result' => $result]);
