<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Study Together</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            display: flex;
            height: 100vh;
            background: #f8f9fa;
        }
        .container {
            display: flex;
            width: 100%;
        }
        .left {
            width: 50%;
            background: linear-gradient(to right, #8e44ad, #c0392b);
            color: white;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        .logo {
            font-size: 24px;
            font-weight: bold;
        }
        .study-preview {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
            margin: 20px 0;
        }
        .study-preview img {
            width: 100px;
            height: 100px;
            border-radius: 10px;
        }
        .user-count {
            font-size: 18px;
            margin-top: 10px;
        }
        .green-dot {
            height: 10px;
            width: 10px;
            background-color: green;
            border-radius: 50%;
            display: inline-block;
        }
        .right {
            width: 50%;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            padding: 40px;
            background: white;
        }
        h2 {
            color: #c0392b;
        }
        form button {
            display: block;
            width: 250px;
            padding: 10px;
            margin: 10px 0;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
        }
        form button:nth-child(1) { background: #fff; border: 1px solid #ccc; }
        form button:nth-child(2) { background: #7289da; color: white; }
        form button:nth-child(3) { background: #1877f2; color: white; }
        form button:nth-child(4) { background: #1da1f2; color: white; }
        form button:nth-child(5) { background: #000; color: white; }
        a { text-decoration: none; color: #c0392b; }
    </style>
</head>
<body>
    <div class="container">
        <div class="left">
            <div class="logo">STUDY <span>TOGETHER</span></div>
            <div class="study-preview">
                <img src="img1.jpeg" alt="Study Session">
                <img src="img2.jpeg" alt="Study Session">
                <img src="img3.jpeg" alt="Study Session">
                <img src="img4.jpeg" alt="Study Session">
            </div>
            <div class="user-count">
                <span class="green-dot"></span> <span id="user-count">1,006</span> users online
            </div>
        </div>
        <div class="right">
            <h2>Welcome to <span>Study Together!</span></h2>
            <p>Join the <b>largest global student community online</b> and say goodbye to lack of motivation.</p>
            <form action="login.php" method="POST">
                <button type="submit" name="google">Join with Google</button>
                <button type="submit" name="discord">Join with Discord</button>
                <button type="submit" name="facebook">Join with Facebook</button>
                <button type="submit" name="twitter">Join with Twitter</button>
                <button type="submit" name="unidays">Join with UNiDAYS</button>
            </form>
            <p>By continuing, you agree to our <a href="#">Terms and Conditions</a> and <a href="#">Privacy Policy</a>.</p>
        </div>
    </div>
    <script>
        document.addEventListener("DOMContentLoaded", function() {
            let userCountElement = document.getElementById("user-count");
            let userCount = 1006;
            setInterval(() => {
                let randomChange = Math.floor(Math.random() * 10) - 5;
                userCount = Math.max(1000, userCount + randomChange);
                userCountElement.textContent = userCount.toLocaleString();
            }, 3000);
        });
    </script>
</body>
</html>
