<?php
// Include database connection
include "db.php";

$message = "";

// Check if token is provided in URL
if (isset($_GET['token'])) {
    $token = $_GET['token'];
    echo "<p>Debug: Token received - " . htmlspecialchars($token) . "</p>";

    // Verify if token exists and is valid
    $stmt = $conn->prepare("SELECT email FROM users WHERE reset_token = ? AND reset_expiry > NOW()");
    $stmt->bind_param("s", $token);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows == 1) {
        $row = $result->fetch_assoc();
        $email = $row['email'];
        echo "<p>Debug: Token is valid for email - " . htmlspecialchars($email) . "</p>"; // Debugging line

        // Handle password reset form submission
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            $new_password = trim($_POST['password']);
            $confirm_password = trim($_POST['confirm_password']);

            if ($new_password === $confirm_password && strlen($new_password) >= 6) {
                // Hash the new password
                $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);

                // Update user's password and clear reset token
                $update_stmt = $conn->prepare("UPDATE users SET password = ?, reset_token = NULL, reset_expiry = NULL WHERE email = ?");
                $update_stmt->bind_param("ss", $hashed_password, $email);
                if ($update_stmt->execute()) {
                    $message = "<p class='success'>Password updated successfully. <a href='login.php'>Login</a></p>";
                } else {
                    $message = "<p class='error'>Failed to update password.</p>";
                }
                $update_stmt->close();
            } else {
                $message = "<p class='error'>Passwords do not match or are too short (min 6 characters).</p>";
            }
        }
    } else {
        // If token is invalid or expired
        $message = "<p class='error'>Invalid or expired token.</p>";
    }
    $stmt->close();
} else {
    $message = "<p class='error'>No reset token provided.</p>";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reset Password</title>
</head>
<body>
    <h2>Reset Password</h2>
    
    <?php if (!empty($message)) echo $message; ?>

    <?php if (isset($email)) { ?>
        <form action="" method="POST">
            <label for="password">New Password:</label>
            <input type="password" id="password" name="password" required>
            <br>
            <label for="confirm_password">Confirm Password:</label>
            <input type="password" id="confirm_password" name="confirm_password" required>
            <br>
            <button type="submit">Reset Password</button>
        </form>
    <?php } ?>
</body>
</html>
