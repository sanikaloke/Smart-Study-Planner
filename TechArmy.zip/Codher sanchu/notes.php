<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Notes & Resources - Smart Study Planner</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
</head>
<body class="bg-gray-100 text-gray-800 font-sans">
    <!-- Header -->
    <header class="bg-purple-600 text-white py-4">
        <div class="container mx-auto flex justify-between items-center">
            <h1 class="text-2xl font-bold">Notes & Resources</h1>
            <nav class="space-x-4">
                <a href="#" class="hover:underline">Home</a>
                <a href="#" class="hover:underline">Dashboard</a>
                <a href="#" class="hover:underline">Contact</a>
            </nav>
        </div>
    </header>

    <!-- Main Content -->
    <main class="container mx-auto py-8">
        <!-- Upload Notes Section -->
        <section class="bg-white shadow-md rounded-lg p-6 mb-8">
            <h2 class="text-xl font-bold mb-4">Upload Your Notes</h2>
            <form action="#" method="POST" enctype="multipart/form-data" class="space-y-4">
                <div>
                    <label for="notes" class="block text-sm font-medium text-gray-700">Upload File</label>
                    <input type="file" id="notes" name="notes" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-purple-500 focus:border-purple-500">
                </div>
                <button type="submit" class="bg-purple-600 text-white px-4 py-2 rounded hover:bg-purple-700">Upload</button>
            </form>
        </section>

        <!-- Summarized Notes Section -->
        <section class="bg-white shadow-md rounded-lg p-6 mb-8">
            <h2 class="text-xl font-bold mb-4">Summarized Notes</h2>
            <p class="text-gray-600">Your uploaded notes will be summarized here for quick review.</p>
            <div class="mt-4 bg-gray-100 p-4 rounded">
                <p class="text-gray-800">No notes uploaded yet. Upload your notes to see the summary.</p>
            </div>
        </section>

        <!-- Flashcards Section -->
        <section class="bg-white shadow-md rounded-lg p-6 mb-8">
            <h2 class="text-xl font-bold mb-4">Flashcards</h2>
            <p class="text-gray-600">Generate flashcards based on your notes for effective learning.</p>
            <div class="mt-4 grid grid-cols-1 md:grid-cols-3 gap-4">
                <div class="bg-purple-100 p-4 rounded shadow">
                    <h3 class="font-bold text-purple-600">Flashcard 1</h3>
                    <p class="text-gray-700">No flashcards generated yet.</p>
                </div>
                <div class="bg-purple-100 p-4 rounded shadow">
                    <h3 class="font-bold text-purple-600">Flashcard 2</h3>
                    <p class="text-gray-700">No flashcards generated yet.</p>
                </div>
                <div class="bg-purple-100 p-4 rounded shadow">
                    <h3 class="font-bold text-purple-600">Flashcard 3</h3>
                    <p class="text-gray-700">No flashcards generated yet.</p>
                </div>
            </div>
        </section>

        <!-- Quizzes Section -->
        <section class="bg-white shadow-md rounded-lg p-6 mb-8">
            <h2 class="text-xl font-bold mb-4">Quizzes</h2>
            <p class="text-gray-600">Test your knowledge with quizzes generated from your notes.</p>
            <div class="mt-4">
                <button class="bg-purple-600 text-white px-4 py-2 rounded hover:bg-purple-700">Start Quiz</button>
            </div>
        </section>

        <!-- Additional Resources Section -->
        <section class="bg-white shadow-md rounded-lg p-6">
            <h2 class="text-xl font-bold mb-4">Additional Resources</h2>
            <p class="text-gray-600">Explore additional resources to enhance your learning.</p>
            <ul class="mt-4 space-y-2">
                <li><a href="#" class="text-purple-600 hover:underline">Resource 1: Study Techniques</a></li>
                <li><a href="#" class="text-purple-600 hover:underline">Resource 2: Time Management</a></li>
                <li><a href="#" class="text-purple-600 hover:underline">Resource 3: Productivity Tools</a></li>
            </ul>
        </section>
    </main>

    <!-- Footer -->
    <footer class="bg-gray-900 text-white py-4">
        <div class="container mx-auto text-center">
            <p>&copy; 2025 Smart Study Planner. All rights reserved.</p>
        </div>
    </footer>
</body>
</html>