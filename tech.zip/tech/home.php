<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Smart Study Planner</title>
    <link rel="stylesheet" href="styles.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 20px;
            background:rgb(37, 116, 207);
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }
        
        .logo {
            font-size: 24px;
            font-weight: bold;
            color:#fff
                }
        
        nav ul {
            list-style: none;
            display: flex;
            gap: 20px;
        }
        
        nav ul li a {
            text-decoration: none;
            color: #fff;
        }
        
        .get-started {
            background: #00b894;
            color: #fff;
            padding: 10px 20px;
            border: none;
            cursor: pointer;
            border-radius: 5px;
        }
        
        .hero {
            background: url('smart.jpeg') no-repeat center center/cover;
            text-align: center;
            padding: 100px 20px;
            color: #fff;
            width: 100%;
            height: 500px;
            max-width: 2000px;
            margin: 0 auto;
        }
        
        .cta {
            background: #d63031;
            text-align: center;
            color: #fff;
            padding: 10px 20px;
            border: none;
            cursor: pointer;
            border-radius: 5px;
        }
        
        .updates {
            text-align: center;
            padding: 50px 20px;
        }
        
        .cards {
            display: flex;
            justify-content: center;
            gap: 20px;
            flex-wrap: wrap;
        }
        
        .card {
            background: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            width: 250px;
            text-align: center;
            transition: transform 0.3s;
        }
        
        .card:hover {
            transform: scale(1.05);
        }
        
        .card img {
            width: 100%;
            border-radius: 10px;
        }
        
        .learn {
            background: #00b894;
            color: #fff;
            padding: 10px 15px;
            border: none;
            cursor: pointer;
            border-radius: 5px;
        }
    </style>
</head>
<body>
    <header>
        <div class="logo"  img src="logo.jpeg" >SmartStudy</div>
        <nav>
            <ul>
                <li><a href="#">Study Planner</a></li>
                <li><a href="#">Goals & Progress</a></li>
                <li><a href="#">Notes & Resources</a></li>
                <li><a href="#">Community</a></li>
                <li><a href="#">Settings</a></li>
                <li><a href="#">Profile</a></li>
            </ul>
        </nav>
        <button class="get-started">Get Started</button>
    </header>
    
    <section class="hero">
        <h1>Study Smart</h1>
        <p>Organize your study habits with our smart, customizable planner!</p>
        <button class="cta">Get Started</button>
    </section>
    
    <section class="updates">
        <h2>Latest Updates</h2>
        <div class="cards">
            <div class="card">
                <img src="img1.jpeg" alt="New Features">
                <h3>New Features Launched Today!</h3>
                <p>March 25, 2025</p>
                <button class="learn">Learn</button>
            </div>
            <div class="card">
                <img src="img2.jpeg" alt="User Profiles">
                <h3>User Profiles Are Here!</h3>
                <p>March 20, 2025</p>
                <button class="learn">Learn</button>
            </div>
            <div class="card">
                <img src="img3.jpeg" alt="Pomodoro Timer">
                <h3>Pomodoro Timer Added!</h3>
                <p>March 15, 2025</p>
                <button class="learn">Learn</button>
            </div>
            <div class="card">
                <img src="img4.jpeg" alt="Join Our Community">
                <h3>Join Our Community Now!</h3>
                <p>March 10, 2025</p>
                <button class="learn">Learn</button>
            </div>
        </div>
    </section>
    
    <script>
        document.addEventListener("DOMContentLoaded", function() {
            document.querySelector(".cta").addEventListener("click", function() {
                alert("Get Started clicked!");
            });
            
            document.querySelectorAll(".learn").forEach(button => {
                button.addEventListener("click", function() {
                    alert("Learn more about: " + this.parentElement.querySelector("h3").innerText);
                });
            });
        });
    </script>
</body>
</html>