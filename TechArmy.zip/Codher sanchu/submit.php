<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    echo "<h2>User Registration Details</h2>";

    echo "Full Name: " . $_POST["name"] . "<br>";
    echo "Email: " . $_POST["email"] . "<br>";
    echo "Password: " . $_POST["password"] . "<br>";
    echo "Gender: " . $_POST["gender"] . "<br>";
    echo "Date of Birth: " . $_POST["dob"] . "<br>";
    echo "Phone Number: " . $_POST["phone"] . "<br>";
    echo "Address: " . nl2br($_POST["address"]) . "<br>";

    if (!empty($_POST["hobbies"])) {
        echo "Hobbies: " . implode(", ", $_POST["hobbies"]) . "<br>";
    } else {
        echo "Hobbies: None selected<br>";
    }

    echo "Country: " . $_POST["country"] . "<br>";

    if (!empty($_FILES["photo"]["name"])) {
        echo "Uploaded Photo: " . $_FILES["photo"]["name"] . "<br>";
    } else {
        echo "No photo uploaded<br>";
    }
} else {
    echo "Invalid request!";
}
?>
