<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Study Planner Calendar</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <link href="https://cdn.jsdelivr.net/npm/fullcalendar@6.1.8/index.global.min.css" rel="stylesheet"/>
  <script src="https://cdn.jsdelivr.net/npm/fullcalendar@6.1.8/index.global.min.js"></script>
</head>

<body class="bg-gray-900 text-white font-sans min-h-screen">
<div class="flex">
  <!-- Sidebar -->
  <aside class="w-64 bg-gray-800 p-6 flex flex-col">
    <h1 class="text-2xl font-bold mb-8">📘 Study Planner</h1>
    <nav class="space-y-4">
      <button onclick="showSection('calendarSection')" class="block w-full text-left py-2 px-4 rounded bg-purple-600 font-semibold">📅 Calendar</button>
      <button onclick="showSection('tasksSection')" class="block w-full text-left py-2 px-4 rounded hover:bg-gray-700">📌 Tasks</button>
      <button onclick="showSection('goalsSection')" class="block w-full text-left py-2 px-4 rounded hover:bg-gray-700">🎯 Goals</button>
      <a href="#" class="block py-2 px-4 rounded hover:bg-gray-700">⚙ Settings</a>
    </nav>
  </aside>

  <!-- Main Content -->
  <main class="flex-1 p-8">
    <!-- CALENDAR SECTION -->
    <section id="calendarSection">
      <div class="flex justify-between items-center mb-8">
        <div>
          <h2 class="text-3xl font-bold">Events Calendar</h2>
          <p class="text-gray-400">Click a date to view events</p>
        </div>
        <button onclick="openAddEventModal()" class="bg-purple-600 px-4 py-2 rounded text-sm font-semibold hover:bg-purple-700">
          ➕ Add Event
        </button>
      </div>
      <div id="calendar" class="bg-gray-800 p-4 rounded-lg shadow-md"></div>
    </section>

    <!-- TASKS SECTION -->
    <section id="tasksSection" class="hidden">
      <div class="mb-8">
        <h2 class="text-3xl font-bold">📌 Task List</h2>
        <p class="text-gray-400">Filter by category and manage your tasks</p>
        <select id="categoryFilter" onchange="renderTasks()" class="mt-2 p-2 rounded text-black">
          <option value="all">All Categories</option>
          <option value="Exam">Exam</option>
          <option value="Project">Project</option>
          <option value="Assignment">Assignment</option>
        </select>
      </div>
      <ul id="taskList" class="space-y-4"></ul>
      <div class="mt-8">
        <h3 class="text-xl font-bold mb-2">Progress</h3>
        <div class="w-full bg-gray-700 rounded-full h-4">
          <div id="progressBar" class="bg-green-500 h-4 rounded-full" style="width: 0%"></div>
        </div>
      </div>
    </section>

    <!-- GOALS SECTION -->
    <section id="goalsSection" class="hidden">
      <div class="mb-8">
        <h2 class="text-3xl font-bold">🎯 Study Goals</h2>
        <p class="text-gray-400 mb-4">Track your academic goals and progress</p>

        <!-- Add Goal Form -->
        <form id="goalForm" class="space-y-4 mb-6">
          <div>
            <label class="block text-sm font-medium mb-1">Goal Title</label>
            <input type="text" id="goalTitle" class="w-full border border-gray-300 text-black rounded px-3 py-2" required />
          </div>
          <div>
            <label class="block text-sm font-medium mb-1">Category</label>
            <select id="goalCategory" class="w-full border border-gray-300 text-black rounded px-3 py-2">
              <option>Exam</option>
              <option>Assignment</option>
              <option>Personal</option>
            </select>
          </div>
          <div>
            <label class="block text-sm font-medium mb-1">Deadline</label>
            <input type="date" id="goalDeadline" class="w-full border border-gray-300 text-black rounded px-3 py-2" />
          </div>
          <div>
            <label class="block text-sm font-medium mb-1">Priority</label>
            <select id="goalPriority" class="w-full border border-gray-300 text-black rounded px-3 py-2">
              <option>High</option>
              <option>Medium</option>
              <option>Low</option>
            </select>
          </div>
          <button type="submit" class="bg-purple-600 hover:bg-purple-700 text-white px-4 py-2 rounded">Add Goal</button>
        </form>

        <!-- Goals List -->
        <ul id="goalList" class="space-y-4"></ul>
      </div>
    </section>

    <!-- View Events Modal -->
    <div id="eventModal" class="fixed inset-0 bg-black bg-opacity-60 hidden items-center justify-center z-50">
      <div class="bg-white text-black rounded-lg p-6 w-96">
        <h3 id="modalTitle" class="text-xl font-bold mb-4">Events</h3>
        <ul id="eventList" class="space-y-2"></ul>
        <button onclick="closeModal()" class="mt-4 bg-purple-600 hover:bg-purple-700 text-white px-4 py-2 rounded">Close</button>
      </div>
    </div>

    <!-- Add Event Modal -->
    <div id="addEventModal" class="fixed inset-0 bg-black bg-opacity-60 hidden items-center justify-center z-50">
      <div class="bg-white text-black rounded-lg p-6 w-96">
        <h3 class="text-xl font-bold mb-4">Add Event</h3>
        <form id="addEventForm">
          <div class="mb-4">
            <label class="block text-sm font-medium mb-1">Event Title</label>
            <input type="text" id="eventTitle" class="w-full border border-gray-300 rounded px-3 py-2" required />
          </div>
          <div class="mb-4">
            <label class="block text-sm font-medium mb-1">Date</label>
            <input type="date" id="eventDate" class="w-full border border-gray-300 rounded px-3 py-2" required />
          </div>
          <div class="mb-4">
            <label class="block text-sm font-medium mb-1">Category</label>
            <select id="eventCategory" class="w-full border border-gray-300 rounded px-3 py-2" required>
              <option value="Exam">Exam</option>
              <option value="Project">Project</option>
              <option value="Assignment">Assignment</option>
            </select>
          </div>
          <div class="flex justify-end gap-2">
            <button type="button" onclick="closeAddEventModal()" class="bg-gray-500 text-white px-4 py-2 rounded">Cancel</button>
            <button type="submit" class="bg-purple-600 hover:bg-purple-700 text-white px-4 py-2 rounded">Add</button>
          </div>
        </form>
      </div>
    </div>
  </main>
</div>

<!-- Scripts -->
<script>
  const eventsData = [];
  const goals = [];
  let calendar;

  document.addEventListener('DOMContentLoaded', function () {
    const calendarEl = document.getElementById('calendar');
    calendar = new FullCalendar.Calendar(calendarEl, {
      initialView: 'dayGridMonth',
      height: 650,
      themeSystem: 'standard',
      events: eventsData,
      dateClick: function(info) {
        const clickedDate = info.dateStr;
        const filteredEvents = eventsData.filter(e => e.date === clickedDate);
        showModal(clickedDate, filteredEvents);
      }
    });
    calendar.render();
    renderTasks();

    document.getElementById("addEventForm").addEventListener("submit", function (e) {
      e.preventDefault();
      const title = document.getElementById("eventTitle").value.trim();
      const date = document.getElementById("eventDate").value;
      const category = document.getElementById("eventCategory").value;
      if (!title || !date || !category) return;
      const color = getCategoryColor(category);
      const newEvent = { title, date, category, color };
      eventsData.push(newEvent);
      calendar.addEvent(newEvent);
      renderTasks();
      closeAddEventModal();
    });

    document.getElementById("goalForm").addEventListener("submit", function(e) {
      e.preventDefault();
      const title = document.getElementById("goalTitle").value;
      const category = document.getElementById("goalCategory").value;
      const deadline = document.getElementById("goalDeadline").value;
      const priority = document.getElementById("goalPriority").value;
      const newGoal = { title, category, deadline, priority, progress: 0 };
      goals.push(newGoal);
      renderGoals();
      this.reset();
    });
  });

  function showModal(date, events) {
    const modal = document.getElementById('eventModal');
    const title = document.getElementById('modalTitle');
    const list = document.getElementById('eventList');
    title.innerText = Events on ${date};
    list.innerHTML = events.length ? events.map(e => <li><span class="inline-block w-3 h-3 rounded-full mr-2" style="background:${e.color}"></span> ${e.title}</li>).join('') : "<li class='text-gray-600'>No events for this date.</li>";
    modal.classList.remove("hidden");
    modal.classList.add("flex");
  }
  function closeModal() {
    document.getElementById('eventModal').classList.add("hidden");
    document.getElementById('eventModal').classList.remove("flex");
  }
  function openAddEventModal() {
    document.getElementById("eventTitle").value = "";
    document.getElementById("eventDate").value = "";
    document.getElementById("eventCategory").value = "Exam";
    document.getElementById("addEventModal").classList.remove("hidden");
    document.getElementById("addEventModal").classList.add("flex");
  }
  function closeAddEventModal() {
    document.getElementById("addEventModal").classList.add("hidden");
    document.getElementById("addEventModal").classList.remove("flex");
  }
  function getCategoryColor(category) {
    return {
      Exam: "#F87171",
      Project: "#60A5FA",
      Assignment: "#FBBF24"
    }[category] || "#A78BFA";
  }
  function renderTasks() {
    const taskList = document.getElementById("taskList");
    const selectedCategory = document.getElementById("categoryFilter").value;
    taskList.innerHTML = "";
    const filtered = selectedCategory === "all" ? eventsData : eventsData.filter(e => e.category === selectedCategory);
    filtered.forEach((event, index) => {
      taskList.innerHTML += `
        <li class="bg-gray-800 p-4 rounded-lg shadow text-white flex justify-between items-center">
          <div>
            <div class="font-semibold text-lg">${event.title}</div>
            <div class="text-gray-400 text-sm">${event.date} | ${event.category}</div>
          </div>
          <div class="flex items-center gap-2">
            <input type="checkbox" onchange="updateProgress()" />
            <button onclick="deleteTask(${index})" class="text-red-400 hover:text-red-600">🗑</button>
          </div>
        </li>`;
    });
    updateProgress();
  }
  function deleteTask(index) {
    if (confirm("Are you sure you want to delete this task?")) {
      eventsData.splice(index, 1);
      renderTasks();
      calendar.removeAllEvents();
      eventsData.forEach(ev => calendar.addEvent(ev));
    }
  }
  function updateProgress() {
    const checkboxes = document.querySelectorAll("#taskList input[type='checkbox']");
    const total = checkboxes.length;
    const completed = [...checkboxes].filter(cb => cb.checked).length;
    const percent = total === 0 ? 0 : Math.round((completed / total) * 100);
    document.getElementById("progressBar").style.width = percent + "%";
  }
  function showSection(sectionId) {
    ["calendarSection", "tasksSection", "goalsSection"].forEach(id => {
      document.getElementById(id).classList.add("hidden");
    });
    document.getElementById(sectionId).classList.remove("hidden");
  }
  function renderGoals() {
    const goalList = document.getElementById("goalList");
    goalList.innerHTML = goals.map((goal, index) => `
      <li class="bg-gray-800 p-4 rounded-lg shadow">
        <div class="font-semibold text-lg">${goal.title}</div>
        <div class="text-sm text-gray-400">Category: ${goal.category} | Priority: ${goal.priority} | Deadline: ${goal.deadline}</div>
        <div class="w-full bg-gray-700 h-3 mt-2 rounded">
          <div class="bg-green-500 h-3 rounded" style="width: ${goal.progress}%"></div>
        </div>
        <div class="text-sm mt-1 text-right text-gray-300">${goal.progress}% Complete</div>
        <button onclick="updateGoalProgress(${index})" class="mt-2 bg-blue-500 hover:bg-blue-600 text-white text-sm px-3 py-1 rounded">
          ➕ +10% Progress
        </button>
      </li>
    `).join('');
  }
  function updateGoalProgress(index) {
    if (goals[index].progress < 100) {
      goals[index].progress += 10;
      if (goals[index].progress > 100) goals[index].progress = 100;
      renderGoals();
    }
  } 
</script>

</body>
</html>