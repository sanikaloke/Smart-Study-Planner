<html lang="en">
 <head>
  <meta charset="utf-8"/>
  <meta content="width=device-width, initial-scale=1.0" name="viewport"/>
  <title>
   Study Together
  </title>
  <script src="https://cdn.tailwindcss.com">
  </script>
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" rel="stylesheet"/>
  <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&amp;display=swap" rel="stylesheet"/>
  <style>
   body {
            font-family: 'Roboto', sans-serif;
        }
  </style>
 </head>
 <body class="bg-gray-100">
 <section class="bg-purple-50 py-12">
        <div class="container mx-auto p-4 text-gray-800">
            <div class="flex flex-col md:flex-row items-center justify-between">
                <div class="relative">
                    <img alt="A study room with a timer and various options on the screen" class="rounded-lg shadow-lg" height="400" src="https://storage.googleapis.com/a1aa/image/XQ8YiEfD2utbJhFx-Q__uGID9lUNMtp25zLTHWx6HMg.jpg" width="600"/>
                </div>
                <div class="mt-6 md:mt-0 md:ml-6 text-center md:text-left">
                    <h2 class="text-2xl font-bold">How it works</h2>
                    <p class="mt-2 text-lg">Create your <span class="font-bold">very own study environment</span> and say goodbye to distractions and procrastination.</p>
                    <p class="mt-2 text-lg">Design your <span class="font-bold">private study room</span> with custom backgrounds, ambient noise, or science-backed binaural beats. Forget the noise and the clutter at home and (virtually) commute into a space that's yours and yours alone.</p>
                    <a class="mt-4 inline-block text-pink-500 font-bold" href="tutorsupport.php">Start Solo Study <i class="fas fa-arrow-right"></i></a>
                </div>
            </div>
        </div>
    </section>
  <main class="relative">
   <img alt="Background image of people in a virtual meeting" class="w-full h-screen object-cover" height="1080" src="https://storage.googleapis.com/a1aa/image/SSAmiMj-6D6mOwRg0dPG8vncTQJwIzdRib7zaLfE9_0.jpg" width="1920"/>
   <div class="absolute inset-0 bg-gradient-to-r from-purple-600 to-pink-500 opacity-75">
   </div>
   <div class="absolute inset-0 flex flex-col items-center justify-center text-center text-white px-4">
    <h1 class="text-4xl md:text-6xl font-bold mb-4">
     We are creating a world where everyone enjoys learning.
    </h1>
    <p class="text-lg md:text-xl font-light">
     We don’t settle for creating Study Together as a platform, a product or a service. We are working hard to make Study Together a
     <span class="font-bold">
      social learning movement
     </span>
     , built on a
     <span class="font-bold">
      virtual study space
     </span>
     where learners are
     <span class="font-bold">
      empowered to reach their full potential together
     </span>
     .
    </p>
   </div>
  </main>
 </body>
</html>
