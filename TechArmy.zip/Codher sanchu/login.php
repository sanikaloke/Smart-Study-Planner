<?php
include "db.php"; // Include database connection
$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);

    // Validate inputs
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $message = "<p class='error'>Invalid email format!</p>";
    } else {
        // Check user credentials
        $stmt = $conn->prepare("SELECT id, password FROM users WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows > 0) {
            $stmt->bind_result($id, $hashed_password);
            $stmt->fetch();

            if (password_verify($password, $hashed_password)) {
                // Login successful
                session_start();
                $_SESSION['user_id'] = $id;
                $_SESSION['email'] = $email;
                header("Location: dashboard.php"); // Redirect to dashboard
                exit();
            } else {
                $message = "<p class='error'>Incorrect password!</p>";
            }
        } else {
            $message = "<p class='error'>Email not found!</p>";
        }
        $stmt->close();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="login.css">
</head>
<body>
    <div class="container">
        <div class="form-box">
            <h2>Login</h2>
           

            <form method="POST" action="login.php">
                <label>Email Address</label>
                <input type="email" name="email" placeholder="you@example.com" required>

                <label>Password</label>
                <input type="password" name="password" placeholder="Enter 6 characters or more" required>

                
                <button type="submit">LOGIN</button>

            
                <p>Don't have an account yet? <a href="register.php">Sign Up</a></p>
            </form>

           
            <?php echo $message; ?>
        </div>

        <div class="illustration">
            <img src="login.jpg" alt="Login Illustration">
        </div>
    </div>
</body>
</html>
