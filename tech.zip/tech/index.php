<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Study Together - Home</title>
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- AOS Animation CSS -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.css" rel="stylesheet">

    <!-- Custom Styles -->
    <style>
        body {
            font-family: Arial, sans-serif;
        }
        header {
            width: 100%; /* Ensure the header spans the full width of the page */
        }
        .navbar {
            height: 120px; /* Increase the height of the navbar */
            align-items: center; /* Center align the content vertically */
        }
        .navbar .container {
            max-width: 100%; /* Remove the default container width restriction */
            padding: 0 20px; /* Optional: Add some padding for spacing */
        }
        .navbar-brand img {
            width: 80px; /* Adjust logo width */
            height: 80px; /* Adjust logo height */
            object-fit: contain; /* Ensure the logo scales properly */
        }
        .hero {
            background: url('main.jpeg') center/cover no-repeat;
            height: 90vh;
            display: flex;
            align-items: center;
            text-align: center;
            color: white;
        }
        .hero h1 {
            font-size: 3rem;
            font-weight: bold;
        }
        .hero p {
            font-size: 1.3rem;
            max-width: 600px;
            margin: auto;
        }
        .counter {
            font-size: 5rem;
            font-weight: bold;
            color: #007bff;
        }
        .card:hover {
            transform: scale(1.05);
            transition: 0.3s;
        }
        footer {
            background: #222;
            color: white;
            padding: 20px 0;
            text-align: center;
        }
    </style>
</head>
<body>

    <!-- Header -->
    <header>
        <nav class="navbar navbar-expand-lg navbar-light bg-light shadow-sm">
            <div class="container">
                <a class="navbar-brand" href="#">
                    <img src="mainlogo.jpg" alt="Logo" class="d-inline-block align-text-top">
                </a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav ms-auto">
                        <li class="nav-item">
                            <a class="nav-link active" href="#hero">Home</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#features">Features</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#testimonials">Testimonials</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#join">Join</a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
    </header>

    <!-- Header / Hero Section -->
    <section class="hero d-flex flex-column justify-content-center text-center">
        <div class="container" data-aos="fade-up">
            <h1>Join the Largest Student Study Community</h1>
            <p>Study with students from around the world and stay motivated.</p>
            <a href="register.php" class="btn btn-primary btn-lg mt-3">Join Now</a>
        </div>
    </section>

    <!-- Counter Section -->
    <section class="text-center my-5">
        <div class="container">
            <div class="row">
                <div class="col-md-4" data-aos="fade-up">
                    <h2 class="counter" id="users">0</h2>
                    <p>Active Students</p>
                </div>
                <div class="col-md-4" data-aos="fade-up" data-aos-delay="200">
                    <h2 class="counter" id="sessions">0</h2>
                    <p>Study Sessions Completed</p>
                </div>
                <div class="col-md-4" data-aos="fade-up" data-aos-delay="400">
                    <h2 class="counter" id="achievements">0</h2>
                    <p>Achievements Unlocked</p>
                </div>
            </div>
        </div>
    </section>

    <!-- Features Section -->
    <section class="container my-5">
        <div class="row text-center">
            <div class="col-md-4" data-aos="fade-right">
                <div class="card p-4 shadow">
                    <h3>Study Rooms</h3>
                    <p>Join global study groups & stay productive together.</p>
                </div>
            </div>
            <div class="col-md-4" data-aos="fade-up">
                <div class="card p-4 shadow">
                    <h3>Live Pomodoro Timers</h3>
                    <p>Focus better with scientifically proven study techniques.</p>
                </div>
            </div>
            <div class="col-md-4" data-aos="fade-left">
                <div class="card p-4 shadow">
                    <h3>Expert Tutor Support</h3>
                    <p>Get instant help from community experts.</p>
                </div>
            </div>
        </div>
    </section>

    <!-- Testimonials -->
    <section class="text-center my-5 bg-light py-5">
        <div class="container" data-aos="zoom-in">
            <h2>What Our Students Say</h2>
            <p>"Studying together has helped me stay motivated and improve my grades!"</p>
            <cite>- Happy Student</cite>
        </div>
    </section>

    <!-- Call to Action -->
    <section id="join" class="text-center my-5">
        <div class="container">
            <h2>Ready to Boost Your Study Game?</h2>
            <a href="#" class="btn btn-success btn-lg mt-3">Join Now for Free</a>
        </div>
    </section>

    <!-- Footer -->
    <footer>
        <div class="container">
            <nav>
                <a href="#">About</a> | 
                <a href="#">FAQ</a> | 
                <a href="#">Contact</a>
            </nav>
            <p>&copy; 2025 Study Together. All rights reserved.</p>
        </div>
    </footer>

    <!-- Bootstrap & JS Dependencies -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <!-- AOS Animation JS -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.js"></script>
    
    <!-- Counter JS -->
    <script>
        AOS.init();

        function animateCounter(id, start, end, duration) {
            let obj = document.getElementById(id);
            let range = end - start;
            let step = Math.abs(Math.floor(duration / range));
            let current = start;
            let timer = setInterval(() => {
                current += 1;
                obj.innerText = current;
                if (current >= end) clearInterval(timer);
            }, step);
        }

        document.addEventListener("DOMContentLoaded", function() {
            animateCounter("users", 0, 1000, 2000);
            animateCounter("sessions", 0, 500, 2500);
            animateCounter("achievements", 0, 750, 2500);
        });
    </script>

</body>
</html>