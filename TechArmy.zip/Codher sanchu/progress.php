<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Progress & Goals - Smart Study Planner</title>
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Chart.js for Progress Visualization -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

    <!-- Custom Styles -->
    <style>
        body {
            font-family: Arial, sans-serif;
        }
        .goal-card {
            border: 1px solid #ddd;
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        .progress-bar {
            height: 20px;
        }
        .chart-container {
            width: 100%;
            max-width: 600px;
            margin: auto;
        }
        footer {
            background: #222;
            color: white;
            padding: 20px 0;
            text-align: center;
        }
    </style>
</head>
<body>

    <!-- Header -->
    <header class="bg-light py-3 shadow-sm">
        <div class="container">
            <h1 class="text-center">Your Goals & Progress</h1>
        </div>
    </header>

    <!-- Goals Section -->
    <section class="container my-5">
        <h2 class="text-center mb-4">Set Your Goals</h2>
        <div class="row">
            <div class="col-md-6">
                <div class="goal-card">
                    <h4>Daily Study Hours</h4>
                    <p>Goal: 4 hours</p>
                    <div class="progress">
                        <div class="progress-bar bg-success" role="progressbar" style="width: 75%;" aria-valuenow="75" aria-valuemin="0" aria-valuemax="100">75%</div>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="goal-card">
                    <h4>Weekly Topics Covered</h4>
                    <p>Goal: 10 topics</p>
                    <div class="progress">
                        <div class="progress-bar bg-info" role="progressbar" style="width: 50%;" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100">50%</div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Progress Visualization -->
    <section class="container my-5">
        <h2 class="text-center mb-4">Progress Overview</h2>
        <div class="chart-container">
            <canvas id="progressChart"></canvas>
        </div>
    </section>

    <!-- Achievements Section -->
    <section class="container my-5">
        <h2 class="text-center mb-4">Achievements</h2>
        <div class="row text-center">
            <div class="col-md-4">
                <div class="goal-card">
                    <h4>Completed 50 Study Hours</h4>
                    <p>Unlocked: Bronze Badge</p>
                </div>
            </div>
            <div class="col-md-4">
                <div class="goal-card">
                    <h4>Mastered 20 Topics</h4>
                    <p>Unlocked: Silver Badge</p>
                </div>
            </div>
            <div class="col-md-4">
                <div class="goal-card">
                    <h4>Perfect Weekly Streak</h4>
                    <p>Unlocked: Gold Badge</p>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer>
        <div class="container">
            <p>&copy; 2025 Smart Study Planner. All rights reserved.</p>
        </div>
    </footer>

    <!-- Chart.js Script -->
    <script>
        const ctx = document.getElementById('progressChart').getContext('2d');
        const progressChart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'],
                datasets: [{
                    label: 'Hours Studied',
                    data: [2, 3, 4, 5, 3, 4, 6],
                    borderColor: '#007bff',
                    backgroundColor: 'rgba(0, 123, 255, 0.2)',
                    borderWidth: 2,
                    tension: 0.4
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        display: true,
                        position: 'top'
                    }
                },
                scales: {
                    x: {
                        title: {
                            display: true,
                            text: 'Days of the Week'
                        }
                    },
                    y: {
                        title: {
                            display: true,
                            text: 'Hours'
                        },
                        beginAtZero: true
                    }
                }
            }
        });
    </script>

</body>
</html>