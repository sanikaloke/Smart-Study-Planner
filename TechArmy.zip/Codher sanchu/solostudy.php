
<?php
session_start();

// Initialize tasks array
if (!isset($_SESSION['tasks'])) {
    $_SESSION['tasks'] = [];
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['task']) && isset($_POST['priority'])) {
    $task = htmlspecialchars($_POST['task']);
    $priority = $_POST['priority'];
    $_SESSION['tasks'][] = ['task' => $task, 'priority' => $priority];
}

// Handle clear tasks
if (isset($_POST['clear'])) {
    $_SESSION['tasks'] = [];
}
?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title>Study Together</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"/>
</head>
<body class="bg-gradient-to-r from-purple-500 to-pink-500 text-white">
    
    <!-- Header Section -->
    <header class="flex justify-between items-center p-6">
        <div class="flex items-center space-x-2">
            <i class="fas fa-network-wired text-3xl"></i>
            <span class="text-2xl font-bold">STUDY TOGETHER</span>
        </div>
        <nav class="space-x-6">
            <a class="hover:underline text-white" href="studytogether.php">How to Study Together</a>
            <a class="hover:underline text-white" href="solostudy.php">Design a Study Universe</a>
            <a class="hover:underline text-white" href="#">Community Events</a>
            <a class="hover:underline text-white" href="#">About</a>
        </nav>
        <a class="bg-orange-500 hover:bg-orange-600 text-white font-bold py-2 px-4 rounded" href="#">Go To App</a>
    </header>
    
    <!-- Study Universe Section -->
    <section class="relative h-screen w-full flex items-center justify-center text-center">
  <!-- Background Image -->
  <div class="absolute inset-0 bg-cover bg-center" style="background-image: url('solo.jpeg'); z-index: 0;"></div>

  <!-- Transparent Overlay -->
  <div class="absolute inset-0 bg-black bg-opacity-50 z-10"></div>

  <!-- Content -->
  <div class="relative z-20 flex flex-col items-center justify-center">
    <h1 class="text-5xl md:text-6xl font-bold mb-6 text-white">Welcome to your very own study universe!</h1>
    <a class="bg-white text-orange-500 font-bold py-3 px-6 rounded-full text-lg mb-6" href="tutorsupport.php">Start Solo Study</a>
    <a class="text-lg hover:underline text-white" href="solostudy.php">How it works <i class="fas fa-chevron-down"></i></a>
  </div>
</section>


    
    <!-- Solo Study Section -->
    <section class="bg-purple-50 flex items-center justify-center min-h-screen text-gray-800">
        <div class="text-center">
            <h1 class="text-4xl font-bold text-brown-800 mb-8">
                Forget the outside world <i class="fas fa-brain"></i>
            </h1>
            <div class="flex flex-col md:flex-row items-center justify-center">
                <div class="text-left mb-8 md:mb-0 md:mr-8">
                    <ul class="space-y-4 text-lg">
                        <li class="flex items-start">
                            <i class="fas fa-chevron-right text-pink-500 mr-2"></i>
                            <span>Do you ever have trouble concentrating because your surroundings are too cluttered?</span>
                        </li>
                        <li class="flex items-start">
                            <i class="fas fa-chevron-right text-pink-500 mr-2"></i>
                            <span>Do you have a hard time zoning out the noise at home?</span>
                        </li>
                        <li class="flex items-start">
                            <i class="fas fa-chevron-right text-pink-500 mr-2"></i>
                            <span>Do you ever wish you could teleport into a different world?</span>
                        </li>
                    </ul>
                </div>
                <div class="relative">
                    <img alt="Person working on a laptop with a notebook" class="rounded-lg shadow-lg" height="250" src="https://storage.googleapis.com/a1aa/image/uk4VF55ZkRyTrUesHfIS4NRiP9sqLjiuT9g0OSCH-y0.jpg" width="400"/>
                </div>
            </div>
        </div>
    </section>
    
    <!-- Study Environment Section -->
    <section class="bg-purple-50 py-12">
        <div class="container mx-auto p-4 text-gray-800">
            <div class="flex flex-col md:flex-row items-center justify-between">
                <div class="relative">
                    <img alt="A study room with a timer and various options on the screen" class="rounded-lg shadow-lg" height="400" src="https://storage.googleapis.com/a1aa/image/XQ8YiEfD2utbJhFx-Q__uGID9lUNMtp25zLTHWx6HMg.jpg" width="600"/>
                </div>
                <div class="mt-6 md:mt-0 md:ml-6 text-center md:text-left">
                    <h2 class="text-2xl font-bold">How it works</h2>
                    <p class="mt-2 text-lg">Create your <span class="font-bold">very own study environment</span> and say goodbye to distractions and procrastination.</p>
                    <p class="mt-2 text-lg">Design your <span class="font-bold">private study room</span> with custom backgrounds, ambient noise, or science-backed binaural beats. Forget the noise and the clutter at home and (virtually) commute into a space that's yours and yours alone.</p>
                    <a class="mt-4 inline-block text-pink-500 font-bold" href="tutorsupport.php">Start Solo Study <i class="fas fa-arrow-right"></i></a>
                </div>
            </div>
        </div>
    </section>
    
    <!-- What to Expect Section -->
    <section class="container mx-auto py-16">
        <h2 class="text-center text-2xl font-bold mb-8">What to Expect:</h2>
        <div class="relative">
            <div class="absolute left-1/2 transform -translate-x-1/2 h-full border-l-2 border-dashed border-red-500"></div>
            <div class="flex flex-col items-center space-y-16">
                <div class="flex items-center w-full">
                    <div class="w-1/2 flex justify-end pr-8">
                        <img alt="Image of a productivity app on a mobile device" class="rounded-lg shadow-lg" height="200" src="https://storage.googleapis.com/a1aa/image/BfCLFO-ftYCE1MbfmP_nW_qws9tGTj6Q2mdM4Du7QXc.jpg" width="300"/>
                    </div>
                    <div class="w-1/2 pl-8">
                        <div class="flex items-center mb-4">
                            <div class="bg-purple-500 text-white rounded-full h-10 w-10 flex items-center justify-center text-lg font-bold">1</div>
                            <h3 class="ml-4 text-xl font-bold">Teleport Yourself to Productivity</h3>
                        </div>
                        <p>Switch to a new world and develop interpersonal skills. Teleport yourself to productivity and motivation. Set the mood, and achieve your goals by studying in a new environment.</p>
                    </div>
                </div>
                <div class="flex items-center w-full">
                    <div class="w-1/2 pr-8">
                        <div class="flex items-center mb-4">
                            <div class="bg-purple-500 text-white rounded-full h-10 w-10 flex items-center justify-center text-lg font-bold">2</div>
                            <h3 class="ml-4 text-xl font-bold">Set the Mood</h3>
                        </div>
                        <p>Set the mood with ambient sounds and a relaxing environment. Whether you need a calm background or a lively atmosphere, find the perfect setting to enhance your productivity.</p>
                    </div>
                    <div class="w-1/2 flex justify-start pl-8">
                        <img alt="Image of a relaxing environment with ambient sounds" class="rounded-lg shadow-lg" height="200" src="https://storage.googleapis.com/a1aa/image/dFkRfMlMyCOImI6XFZ_-69kyYj2m55pxPjCgzIM670s.jpg" width="300"/>
                    </div>
                </div>
                <div class="flex items-center w-full">
                    <div class="w-1/2 flex justify-end pr-8">
                        <img alt="Image of a study app showing progress and goals" class="rounded-lg shadow-lg" height="200" src="https://storage.googleapis.com/a1aa/image/3CJ9zi3PGf065VbShF8yGogRw0tKTK6HnM-81Xwsppg.jpg" width="300"/>
                    </div>
                    <div class="w-1/2 pl-8">
                        <div class="flex items-center mb-4">
                            <div class="bg-purple-500 text-white rounded-full h-10 w-10 flex items-center justify-center text-lg font-bold">3</div>
                            <h3 class="ml-4 text-xl font-bold">Study at Your Own Pace</h3>
                        </div>
                        <p>Manage your time effectively and study at your own pace. Track your progress and set achievable goals to stay motivated and on track.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>
    
    <!-- New Section -->
    <section class="bg-white text-gray-800 py-16">
        <header class="bg-gray-900 text-white text-center py-4">
            <h1 class="text-3xl font-bold">
                What are you waiting for?
                <i class="fas fa-heart text-purple-500"></i>
            </h1>
        </header>
        <main class="flex flex-col items-center justify-center min-h-screen">
            <div class="bg-purple-100 rounded-lg p-8 max-w-4xl mx-auto text-center">
                <div class="flex flex-col md:flex-row items-center">
                    <img alt="Illustration of a person studying with books and other study materials" class="w-64 h-64 mx-auto md:mx-0" height="300" src="https://storage.googleapis.com/a1aa/image/CRmOcAKF5blZ2ISlFdHIQD4NJaaub0fktqEJdVrjbUY.jpg" width="300"/>
                    <div class="md:ml-8 mt-4 md:mt-0 text-left">
                        <p class="text-lg font-semibold">
                            When creating your
                            <span class="font-bold">ideal study environment</span>, the only limit is your imagination. Escape the chaos and the noise, and zone in on your
                            <span class="font-bold">priorities</span>.
                        </p>
                        <button class="mt-4 bg-red-500 text-white py-2 px-4 rounded">Start Studying</button>
                    </div>
                </div>
            </div>
        </main>
    </section>

    <section class="bg-white text-gray-800 py-16">
        <div class="container mx-auto p-4">
            <h2 class="text-3xl font-bold text-center mb-6">🎯 Task Manager</h2>
            <form method="POST" class="mb-4">
                <input type="text" name="task" placeholder="Enter your task..." required class="border rounded p-2 w-full mb-2"/>
                <select name="priority" required class="border rounded p-2 w-full mb-2">
                    <option value="">Select Priority</option>
                    <option value="High">🔥 High</option>
                    <option value="Medium">⚠️ Medium</option>
                    <option value="Low">✅ Low</option>
                </select>
                <button type="submit" class="bg-blue-500 text-white py-2 px-4 rounded">Add Task</button>
                <button type="submit" name="clear" class="bg-red-500 text-white py-2 px-4 rounded float-right">Clear All</button>
            </form>

            <?php if (!empty($_SESSION['tasks'])): ?>
                <?php foreach ($_SESSION['tasks'] as $t): ?>
                    <div class="task border-l-4 border-<?php echo strtolower($t['priority']); ?>-500 p-2 mb-2">
                        <?php echo htmlspecialchars($t['task']); ?> 
                        <span class="text-<?php echo strtolower($t['priority']); ?>-500">[<?php echo $t['priority']; ?>]</span>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <p class="text-center">No tasks added yet.</p>
            <?php endif; ?>
        </div>
    </section>

</body>
</html>