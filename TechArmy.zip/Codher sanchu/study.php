<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Study Planner</title>
    <link rel="stylesheet" href="styles.css">
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            margin: 0;
            padding: 0;
            background: linear-gradient(to right, #e3f2fd, #f8f9fa);
        }
        
        .container {
            max-width: 1000px;
            margin: auto;
            padding: 20px;
        }
        
        .planner-header {
            background: #007BFF;
            color: white;
            text-align: center;
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.2);
            font-size: 1.5em;
        }
        
        .schedule {
            display: grid;
            grid-template-columns: repeat(7, 1fr);
            gap: 12px;
            margin-top: 25px;
        }
        
        .day {
            background: white;
            padding: 18px;
            text-align: center;
            border-radius: 10px;
            box-shadow: 0 3px 8px rgba(0, 0, 0, 0.15);
            font-weight: bold;
            transition: transform 0.3s;
        }
        
        .day:hover {
            transform: scale(1.05);
            background: #cce5ff;
        }
        
        .task-list {
            background: white;
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
            margin-top: 30px;
        }
        
        .task {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 12px;
            border-bottom: 1px solid #ddd;
            transition: background 0.3s;
        }
        
        .task:last-child {
            border-bottom: none;
        }
        
        .task:hover {
            background: #f1f1f1;
        }
        
        .task button {
            background: red;
            color: white;
            border: none;
            padding: 8px 12px;
            cursor: pointer;
            border-radius: 6px;
            transition: background 0.3s;
        }
        
        .task button:hover {
            background: darkred;
        }
        
        .add-task {
            margin-top: 20px;
            display: flex;
            gap: 10px;
        }
        
        .add-task input {
            flex-grow: 1;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 6px;
        }
        
        .add-task button {
            background: green;
            color: white;
            border: none;
            padding: 10px 15px;
            cursor: pointer;
            border-radius: 6px;
            transition: background 0.3s;
        }
        
        .add-task button:hover {
            background: darkgreen;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="planner-header">
            <h1>📅 Study Planner</h1>
            <p>Plan your week, set tasks, and stay on track!</p>
        </div>
        
        <div class="schedule">
            <div class="day">Monday</div>
            <div class="day">Tuesday</div>
            <div class="day">Wednesday</div>
            <div class="day">Thursday</div>
            <div class="day">Friday</div>
            <div class="day">Saturday</div>
            <div class="day">Sunday</div>
        </div>
        
        <div class="task-list">
            <h2>📌 Tasks</h2>
            <div class="add-task">
                <input type="text" id="task-input" placeholder="Add a new task...">
                <button onclick="addTask()">Add</button>
            </div>
            <div id="task-container">
                <div class="task">
                    <span>Complete Math Homework</span>
                    <button onclick="removeTask(this)">Remove</button>
                </div>
                <div class="task">
                    <span>Read 10 pages of Science</span>
                    <button onclick="removeTask(this)">Remove</button>
                </div>
                <div class="task">
                    <span>Practice Programming</span>
                    <button onclick="removeTask(this)">Remove</button>
                </div>
            </div>
        </div>
    </div>

    <script>
        function addTask() {
            let taskInput = document.getElementById('task-input');
            let taskContainer = document.getElementById('task-container');
            if (taskInput.value.trim() === '') {
                alert('Please enter a task!');
                return;
            }
            
            let newTask = document.createElement('div');
            newTask.classList.add('task');
            newTask.innerHTML = `<span>${taskInput.value}</span><button onclick="removeTask(this)">Remove</button>`;
            taskContainer.appendChild(newTask);
            
            taskInput.value = '';
        }
        
        function removeTask(button) {
            button.parentElement.remove();
        }
    </script>
</body>
</html>
