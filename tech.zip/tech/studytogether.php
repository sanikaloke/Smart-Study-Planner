<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Study Together</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" rel="stylesheet"/>
    <style>
        body {
            font-family: Arial, sans-serif;
            text-align: center;
            margin: 0;
            padding: 0;
            background-color: #f8f5fc;
            overflow-x: hidden;
            min-height: 200vh; /* Ensures enough scrollable space */
        }

        /* Study Together Section */
        .container {
            display: flex;
            justify-content: space-around;
            align-items: center;
            height: 100vh;
            padding: 20px;
        }

        .text-content {
            max-width: 40%;
            text-align: left;
        }

        .text-content h1 {
            font-size: 4rem;
            font-weight: bold;
            color: #2d1b1b;
            opacity: 0;
            transform: scale(0.8);
            animation: fadeIn 0.5s ease-out forwards;
        }

        .text-content p {
            font-size: 1rem;
            color: #333;
            opacity: 0;
            transform: scale(0.8);
            animation: fadeIn 0.5s ease-out 0.3s forwards;
            max-width: 500px;
            line-height: 1.6;
        }

        .btn {
            display: inline-block;
            background: #ff6363;
            color: white;
            padding: 15px 30px;
            font-size: 1.2rem;
            text-decoration: none;
            border-radius: 5px;
            margin-top: 20px;
            transition: background 0.3s;
        }

        .btn:hover {
            background: #ff4747;
        }

        .image-section {
            max-width: 50%;
            opacity: 0;
            transform: scale(0.8);
            animation: fadeIn 0.5s ease-out 0.2s forwards;
        }

        .image-section img {
            width: 100%;
        }

        /* New Here? Welcome Section */
        .welcome-section {
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 60px;
            background-color: #f9f9f7; /* Off-white section background */
        }

        /* Add animation to the container */
        .welcome-container {
            background:rgb(234, 234, 234);
            border-radius: 20px;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
            max-width: 900px;
            display: flex;
            align-items: center;
            padding: 50px;
            gap: 20px;
            position: relative;
            border: 15px solid white;
            overflow: hidden;
            
            /* Animation */
            opacity: 0;
            transform: translateY(50px); /* Start from below */
            animation: fadeSlideIn 1s ease-out forwards;
        }

        /* Right-side curved effect */
        .welcome-container::before {
            content: "";
            position: absolute;
            width: 50%; /* Adjust to match the curve size */
            height: 100%;
            background: white; /* White half */
            border-top-left-radius: 100%;
            border-bottom-left-radius: 100%;
            right: 0; /* Move it to the right */
            top: 0;
            transform: translateX(25%); /* Fine-tune positioning */
        }

        .welcome-text {
            flex: 1;
            text-align: left;
        }

        /* Animate the heading */
        .welcome-text h2 {
            font-size: 3rem;
            font-weight: bold;
            color: #000;

            /* Animation */
            opacity: 0;
            transform: translateY(-20px); /* Moves down into place */
            animation: fadeSlideInText 1s ease-out 0.5s forwards;
        }

        /* Animate the subheading (paragraphs) */
        .welcome-text p {
            font-size: 1.2rem;
            color: #333;
            line-height: 1.8;

            /* Animation */
            opacity: 0;
            transform: translateY(20px); /* Moves up into place */
            animation: fadeSlideInText 1s ease-out 0.8s forwards;
        }

        /* Keyframes for text animations */
        @keyframes fadeSlideInText {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .cta-button {
            display: inline-block;
            background: #ff6363;
            color: white;
            padding: 18px 30px;
            font-size: 1.2rem;
            text-decoration: none;
            font-weight: bold;
            border-radius: 8px;
            transition: background 0.3s;
            border: none;
            cursor: pointer;
            margin-top: 20px;
        }

        .cta-button:hover {
            background: #ff4747;
        }

        .welcome-image {
            flex: 0.8;
            display: flex;
            justify-content: center;
            align-items: center;
            position: relative;
        }

        /* Circular Image with Larger White Border */
        .welcome-image img {
            width: 180px;
            height: 180px;
            border-radius: 50%;
            object-fit: cover;
            border: 8px solid white; /* Larger white border */
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.2);
        }

        /* Decorative orange gradient shape */
        .decorative-shape {
            position: absolute;
            width: 250px;
            height: 250px;
            background: linear-gradient(45deg, #ff6a6a, #ff914d);
            border-radius: 50%;
            bottom: -200px;
            right: -140px;
        }

        /* Animation Keyframes */
        @keyframes fadeSlideIn {
            from {
                opacity: 0;
                transform: translateY(50px); /* Start position */
            }
            to {
                opacity: 1;
                transform: translateY(0); /* Normal position */
            }
        }

        /* Fade-in animation */
        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: scale(0.8);
            }
            to {
                opacity: 1;
                transform: scale(1);
            }
        }
    </style>
</head>
<body>
    <!-- Study Together Section -->
    <div class="container">
        <div class="text-content">
            <h1>There is waaay more to study</h1>
            <p>It's about time to enjoy studying! As part of a supportive community,<br> 
                you will feel inspired again and held accountable to reach your goals.<br> 
                Let us <strong>guide you</strong> through your <strong>study sessions</strong>,<br> 
                and celebrate your <strong>success with you.</strong> Together we go further!
            </p>
            <a href="tutorsupport.php" class="btn">Join Study Together</a>
        </div>
        <div class="image-section">
            <img src="studytogether.avif" alt="Study Together Illustration">
        </div>
    </div>

    <!-- New Here? Welcome Section -->
    <div class="welcome-section">
        <div class="welcome-container">
            <div class="welcome-text">
                <h2>New here? Welcome.</h2>
                <p>We’re here to help you find the motivation boost you need. Take a tour of 
                    our platform with Nadir to learn all the tips and tricks - it’s just two and a 
                    half minutes of your day.</p>
                <p>Don’t just take our word for it, let Nadir show you the ropes!</p>
                <button class="cta-button">Take Your Tour Here</button>
            </div>
            <div class="welcome-image">
                <img src="peace.png" alt="Welcome Image">
                <div class="decorative-shape"></div>
            </div>
        </div>
    </div>

    <!-- Study Rooms Section -->
    <div class="max-w-4xl mx-auto p-4">
        <h1 class="text-2xl font-bold text-center mb-4">
            1. Choose a room &amp; meet other students
        </h1>
        <p class="text-center mb-8">
            With
            <span class="font-bold">
                ambiance music
            </span>
            , with the
            <span class="font-bold">
                camera
            </span>
            on or off, or a
            <span class="font-bold">
                supportive and helpful chat
            </span>
            with other students.
            <br/>
            You choose the room that best fits you.
        </p>
        <div class="mb-8">
            <div class="flex items-center mb-2">
                <span class="bg-red-500 text-white text-xs font-bold px-2 py-1 rounded-full mr-2">
                    New
                </span>
                <h2 class="text-lg font-bold">
                    Solo study room
                </h2>
            </div>
            <div class="bg-blue-900 text-white rounded-lg p-4 flex items-center justify-between">
                <div>
                    <div class="flex items-center mb-2">
                        <span class="bg-green-500 text-xs font-bold px-2 py-1 rounded-full mr-2">
                            Live in-app
                        </span>
                        <h3 class="text-lg font-bold">
                            Solo study
                            <i class="fas fa-book">
                            </i>
                        </h3>
                    </div>
                    <p>
                        100% focus! Set the scene with atmospheric backgrounds, use timer and goal setting and study in your solo study room.
                    </p>
                </div>
                <button  href="tutorsupport.php" class="bg-white text-blue-900 font-bold py-2 px-4 rounded-lg"">
                    Start a solo session
                </button>
            </div>
        </div>
        <div>
            <h2 class="text-lg font-bold mb-4">
                Group study rooms
            </h2>
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div class="bg-blue-700 text-white rounded-lg p-4 flex flex-col justify-between">
                    <div>
                        <div class="flex items-center mb-2">
                            <span class="bg-green-500 text-xs font-bold px-2 py-1 rounded-full mr-2">
                                Live in-app
                            </span>
                            <h3 class="text-lg font-bold">
                                Study for Ukraine
                                <i class="fas fa-flag">
                                </i>
                            </h3>
                        </div>
                        <p>
                            You collect study minutes, we collect money to support Ukraine
                        </p>
                        <div class="flex items-center mt-2">
                            <img alt="User avatar" class="rounded-full mr-1" height="20" src="https://placehold.co/20x20" width="20"/>
                            <img alt="User avatar" class="rounded-full mr-1" height="20" src="https://placehold.co/20x20" width="20"/>
                            <img alt="User avatar" class="rounded-full mr-1" height="20" src="https://placehold.co/20x20" width="20"/>
                            <img alt="User avatar" class="rounded-full mr-1" height="20" src="https://placehold.co/20x20" width="20"/>
                            <img alt="User avatar" class="rounded-full mr-1" height="20" src="https://placehold.co/20x20" width="20"/>
                        </div>
                    </div>

                    <button onclick="window.location.href='tutorsupport.php'" class="bg-yellow-500 text-blue-700 font-bold py-2 px-4 rounded-lg mt-4">
                        Join group study
                    </button>

                </div>
                <div class="bg-red-500 text-white rounded-lg p-4 flex flex-col justify-between">
                    <div>
                        <div class="flex items-center mb-2">
                            <span class="bg-green-500 text-xs font-bold px-2 py-1 rounded-full mr-2">
                                Live in-app
                            </span>
                            <h3 class="text-lg font-bold">
                                Group focus | 50 min
                                <i class="fas fa-clock">
                                </i>
                            </h3>
                        </div>
                        <p>
                            Join and start studying right away with the community!
                        </p>
                        <div class="flex items-center mt-2">
                            <img alt="User avatar" class="rounded-full mr-1" height="20" src="https://placehold.co/20x20" width="20"/>
                            <img alt="User avatar" class="rounded-full mr-1" height="20" src="https://placehold.co/20x20" width="20"/>
                            <img alt="User avatar" class="rounded-full mr-1" height="20" src="https://placehold.co/20x20" width="20"/>
                            <img alt="User avatar" class="rounded-full mr-1" height="20" src="https://placehold.co/20x20" width="20"/>
                            <img alt="User avatar" class="rounded-full mr-1" height="20" src="https://placehold.co/20x20" width="20"/>
                        </div>
                    </div>
                    <button onclick="window.location.href='tutorsupport.php'" class="bg-white text-red-500 font-bold py-2 px-4 rounded-lg mt-4">
                        Join group study
                    </button>
                </div>
                <div class="bg-yellow-500 text-white rounded-lg p-4 flex flex-col justify-between">
                    <div>
                        <div class="flex items-center mb-2">
                            <span class="bg-green-500 text-xs font-bold px-2 py-1 rounded-full mr-2">
                                Live in-app
                            </span>
                            <h3 class="text-lg font-bold">
                                Group focus | 25 min
                                <i class="fas fa-clock">
                                </i>
                            </h3>
                        </div>
                        <p>
                            Join and start studying right away with the community!
                        </p>
                        <div class="flex items-center mt-2">
                            <img alt="User avatar" class="rounded-full mr-1" height="20" src="https://placehold.co/20x20" width="20"/>
                            <img alt="User avatar" class="rounded-full mr-1" height="20" src="https://placehold.co/20x20" width="20"/>
                            <img alt="User avatar" class="rounded-full mr-1" height="20" src="https://placehold.co/20x20" width="20"/>
                            <img alt="User avatar" class="rounded-full mr-1" height="20" src="https://placehold.co/20x20" width="20"/>
                            <img alt="User avatar" class="rounded-full mr-1" height="20" src="https://placehold.co/20x20" width="20"/>
                        </div>
                    </div>
                    <button  onclick="window.location.href='tutorsupport.php'" class="bg-red-500 text-white font-bold py-2 px-4 rounded-lg mt-4">
                        Join group study
                    </button>
                </div>
                <div class="bg-gray-200 text-gray-800 rounded-lg p-4 flex flex-col justify-between">
                    <div>
                        <div class="flex items-center mb-2">
                            <span class="bg-blue-500 text-xs font-bold px-2 py-1 rounded-full mr-2">
                                On Zoom
                            </span>
                            <h3 class="text-lg font-bold">
                                Study &amp; chat
                                <i class="fas fa-comments">
                                </i>
                            </h3>
                        </div>
                        <p>
                            Here we study &amp; chat to motivate each other. Zoom account required.
                        </p>
                        <div class="flex items-center mt-2">
                            <img alt="User avatar" class="rounded-full mr-1" height="20" src="https://placehold.co/20x20" width="20"/>
                            <img alt="User avatar" class="rounded-full mr-1" height="20" src="https://placehold.co/20x20" width="20"/>
                            <img alt="User avatar" class="rounded-full mr-1" height="20" src="https://placehold.co/20x20" width="20"/>
                            <img alt="User avatar" class="rounded-full mr-1" height="20" src="https://placehold.co/20x20" width="20"/>
                            <img alt="User avatar" class="rounded-full mr-1" height="20" src="https://placehold.co/20x20" width="20"/>
                        </div>
                    </div>
                    <button  onclick="window.location.href='tutorsupport.php'"class="bg-purple-500 text-white font-bold py-2 px-4 rounded-lg mt-4">
                        Join group study
                    </button>
                </div>
            </div>
        </div>
        <div class="text-center mt-8">
            <button  onclick="window.location.href='tutorsupport.php'" class="bg-red-500 text-white font-bold py-3 px-6 rounded-lg">
                Join the community
            </button>
        </div>
    </div>

    
    <div class="flex flex-col md:flex-row items-center md:items-start space-y-0 md:space-y-0 md:space-x-8 p-8 justify-center ">
        <div class="bg-white shadow-lg rounded-lg p-6 ">
            <div class="flex justify-between items-center mb-4">
                <h2 class="text-gray-700 font-bold">Study Timer</h2>
                <i class="fas fa-info-circle text-purple-500"></i>
            </div>
            <div class="flex justify-center items-center mb-4">
                <div class="relative">
                    <svg class="w-32 h-32">
                        <circle class="text-gray-300" stroke-width="10" stroke="currentColor" fill="transparent" r="50" cx="64" cy="64"/>
                        <circle class="text-purple-500" stroke-width="10" stroke-dasharray="314" stroke-dashoffset="0" stroke-linecap="round" stroke="currentColor" fill="transparent" r="50" cx="64" cy="64"/>
                    </svg>
                    <div class="absolute inset-0 flex items-center justify-center">
                        <span class="text-purple-500 text-3xl font-semibold">100</span>
                    </div>
                </div>
            </div>
            <div class="flex justify-between items-center">
                <i class="fas fa-pause text-red-500"></i>
                <i class="fas fa-stop text-red-500"></i>
            </div>
        </div>
        <div class="space-y-4">
            <div class="flex items-center space-x-2">
                <i class="fas fa-check-circle text-green-500"></i>
                <span class="bg-green-100 text-green-700 px-4 py-2 rounded-lg">Read Chapter 3 Anatomy</span>
            </div>
            <div class="flex items-center space-x-2">
                <i class="fas fa-check-circle text-green-500"></i>
                <span class="bg-green-100 text-green-700 px-4 py-2 rounded-lg">Complete exercises 12-14</span>
            </div>
            <div class="flex items-center space-x-2">
                <i class="fas fa-check-circle text-green-500"></i>
                <span class="bg-green-100 text-green-700 px-4 py-2 rounded-lg">Study chapters 4 - 5 Math</span>
            </div>
            <div class="flex items-center space-x-2">
                <i class="fas fa-check-circle text-green-500"></i>
                <span class="bg-green-100 text-green-700 px-4 py-2 rounded-lg">Summarize last video lecture</span>
            </div>
        </div>
        <div class="max-w-md">
            <h2 class="text-2xl font-bold text-gray-800">2. Start the timer & set your goals</h2>
            <p class="text-gray-700 mt-4">Choose longer or short <span class="font-bold">focus periods</span> – 30, 50, or 100 study minutes alternated with 5-minute <span class="font-bold">breaks</span>. Preparation and <span class="font-bold">structure</span> are key to productivity and balance.</p>
        </div>
    </div>

    
    <div class="container mx-auto px-4 py-8 flex flex-col lg:flex-row items-center justify-between">
   <div class="lg:w-1/2">
    <h2 class="text-3xl font-bold mb-4">
     3. „I’m stuck. Heeelp!“
    </h2>
    <p class="text-lg text-gray-700">
     Oh, it happens to all of us. Feeling unmotivated, stressed, or stuck on an assignment? Our community and
     <span class="text-red-500 font-bold">
      tutors
     </span>
     are here for you :)
    </p>
   </div>
   <div class="lg:w-1/2 flex justify-center lg:justify-end mt-8 lg:mt-0">
    <div class="relative">
     <img alt="Mathematical equations on a whiteboard" class="rounded-lg shadow-lg" height="200" src="https://storage.googleapis.com/a1aa/image/MJlV7_t3kcliO3QH_cRkFK5rskQwuMk_rOqgq15KGbg.jpg" width="300"/>
     <div class="absolute top-0 left-0 w-12 h-12 rounded-full overflow-hidden border-2 border-white">
      <img alt="Profile picture of a tutor" height="48" src="https://storage.googleapis.com/a1aa/image/w0dSEUDt7_utXjMqZg7-8jS_2VdhqK9j5znrExJ1H0s.jpg" width="48"/>
     </div>
     <div class="absolute top-0 right-0 w-12 h-12 rounded-full overflow-hidden border-2 border-white">
      <img alt="Profile picture of a tutor" height="48" src="https://storage.googleapis.com/a1aa/image/w0dSEUDt7_utXjMqZg7-8jS_2VdhqK9j5znrExJ1H0s.jpg" width="48"/>
     </div>
     <div class="absolute bottom-0 left-0 w-12 h-12 rounded-full overflow-hidden border-2 border-white">
      <img alt="Profile picture of a tutor" height="48" src="https://storage.googleapis.com/a1aa/image/w0dSEUDt7_utXjMqZg7-8jS_2VdhqK9j5znrExJ1H0s.jpg" width="48"/>
     </div>
     <div class="absolute bottom-0 right-0 w-12 h-12 rounded-full overflow-hidden border-2 border-white">
      <img alt="Profile picture of a tutor" height="48" src="https://storage.googleapis.com/a1aa/image/w0dSEUDt7_utXjMqZg7-8jS_2VdhqK9j5znrExJ1H0s.jpg" width="48"/>
     </div>
    </div>
    <div class="relative ml-4">
     <img alt="Venn diagram on a whiteboard" class="rounded-lg shadow-lg" height="200" src="https://storage.googleapis.com/a1aa/image/lVAfSc-knCjrIrEJ33WtzjWtm_Fp6jJjla294D1eB88.jpg" width="300"/>
     <div class="absolute top-0 left-0 w-12 h-12 rounded-full overflow-hidden border-2 border-white">
      <img alt="Profile picture of a tutor" height="48" src="https://storage.googleapis.com/a1aa/image/w0dSEUDt7_utXjMqZg7-8jS_2VdhqK9j5znrExJ1H0s.jpg" width="48"/>
     </div>
     <div class="absolute top-0 right-0 w-12 h-12 rounded-full overflow-hidden border-2 border-white">
      <img alt="Profile picture of a tutor" height="48" src="https://storage.googleapis.com/a1aa/image/w0dSEUDt7_utXjMqZg7-8jS_2VdhqK9j5znrExJ1H0s.jpg" width="48"/>
     </div>
     <div class="absolute bottom-0 left-0 w-12 h-12 rounded-full overflow-hidden border-2 border-white">
      <img alt="Profile picture of a tutor" height="48" src="https://storage.googleapis.com/a1aa/image/w0dSEUDt7_utXjMqZg7-8jS_2VdhqK9j5znrExJ1H0s.jpg" width="48"/>
     </div>
     <div class="absolute bottom-0 right-0 w-12 h-12 rounded-full overflow-hidden border-2 border-white">
      <img alt="Profile picture of a tutor" height="48" src="https://storage.googleapis.com/a1aa/image/w0dSEUDt7_utXjMqZg7-8jS_2VdhqK9j5znrExJ1H0s.jpg" width="48"/>
     </div>
    </div>
   </div>
  </div>

  <div class="container mx-auto px-4 py-8 flex flex-col md:flex-row items-center">
        <div class="mb-8 md:mb-0">
            <img alt="Person practicing mindfulness" class="rounded-lg shadow-lg" height="150" src="https://storage.googleapis.com/a1aa/image/5tO9O0lb-2_KQ6WH-7nCsjmm6FXuMsQGjsmLyOz5bDc.jpg" width="200"/>
        </div>
        <div class="md:ml-8 text-center md:text-left">
            <h2 class="text-2xl md:text-3xl font-bold mb-4">
                4. Have a break or get ready to rock!
            </h2>
            <p class="text-gray-700 mb-2">
                Resting your mind is just as crucial for success as the study itself. Join the
                <span class="text-red-500">
                    Together Sessions
                </span>
                for a
                <span class="font-bold">
                    mindfulness
                </span>
                session or a
                <span class="font-bold">
                    boot camp
                </span>
                , or browse through a
                <span class="font-bold">
                    collection of audios and videos
                </span>
                with meditation and breathing exercises.
            </p>
        </div>
    </div>

    <div class="container mx-auto px-4 py-8">
   <div class="flex flex-col lg:flex-row items-center lg:items-start">
    <div class="lg:w-1/2">
     <h2 class="text-2xl font-bold mb-4">
      5. Celebrate your victories
     </h2>
     <p class="text-lg mb-4">
      A community that studies together
      <span class="font-bold">
       achieves goals together
      </span>
      ! See your
      <span class="font-bold">
       progress
      </span>
      every day on your
      <span class="font-bold">
       stats
      </span>
      and the community
      <span class="font-bold">
       leaderboard
      </span>
      . A gamified experience will keep you engaged and connected.
     </p>
    </div>
    <div class="lg:w-1/2 flex flex-col items-center lg:items-end">
     <div class="flex flex-col lg:flex-row items-center lg:items-start">
      <div class="bg-white shadow-lg rounded-lg p-4 mb-4 lg:mb-0 lg:mr-4">
       <div class="flex items-center mb-4">
        <i class="fas fa-clock text-blue-500 text-2xl mr-2">
        </i>
        <div>
         <p class="text-sm">
          Today
         </p>
         <p class="text-xl font-bold">
          5.2 hrs
         </p>
        </div>
       </div>
       <div class="flex items-center mb-4">
        <i class="fas fa-trophy text-orange-500 text-2xl mr-2">
        </i>
        <div>
         <p class="text-sm">
          Current rank
         </p>
         <p class="text-xl font-bold">
          #32
         </p>
        </div>
       </div>
       <div class="flex items-center">
        <i class="fas fa-gem text-purple-500 text-2xl mr-2">
        </i>
        <div class="flex space-x-2">
         <span class="w-6 h-6 bg-blue-500 rounded-full">
         </span>
         <span class="w-6 h-6 bg-indigo-500 rounded-full">
         </span>
         <span class="w-6 h-6 bg-purple-500 rounded-full">
         </span>
         <span class="w-6 h-6 bg-green-500 rounded-full">
         </span>
         <span class="w-6 h-6 bg-yellow-500 rounded-full">
         </span>
        </div>
       </div>
      </div>
      <div class="bg-white shadow-lg rounded-lg p-4">
       <div class="relative">
        <div class="absolute top-0 right-0 bg-orange-500 w-8 h-8 rounded-full">
        </div>
        <div class="w-full h-48">
         <img alt="Graph showing progress over time" class="w-full h-full object-cover rounded-lg" height="200" src="https://storage.googleapis.com/a1aa/image/pRHFnyPTpW-jGkWrBKgtLwsA1oLSZZ2C2oZVImNBxq8.jpg" width="300"/>
        </div>
       </div>
      </div>
     </div>
     <div class="flex space-x-2 mt-4">
      <img alt="Fire icon 1" class="w-8 h-8" height="32" src="https://storage.googleapis.com/a1aa/image/QXpaHtxolhsEsbOn3RjD2K_MH4f5zPSI3ptlZvc2t7A.jpg" width="32"/>
      <img alt="Fire icon 2" class="w-8 h-8" height="32" src="https://storage.googleapis.com/a1aa/image/yKX4l59glXiUSQahn4IfAexeJ0SwR0j9AamUr3W8dxM.jpg" width="32"/>
      <img alt="Fire icon 3" class="w-8 h-8" height="32" src="https://storage.googleapis.com/a1aa/image/h0Eq6c0orrR0xR4c6GG8L1BQ44eFd3UJ8ur1gsxr8hw.jpg" width="32"/>
      <img alt="Fire icon 4" class="w-8 h-8" height="32" src="https://storage.googleapis.com/a1aa/image/dFZ6swfwF6OXAdQX7o67BTX-tq6rPqBrvoH98ltMoO0.jpg" width="32"/>
      <img alt="Fire icon 5" class="w-8 h-8" height="32" src="https://storage.googleapis.com/a1aa/image/bKJyiqcQRI3an-HD5AANHJxZ684MAtMlFRM-Je2IT74.jpg" width="32"/>
     </div>
    </div>
   </div>
  </div>


  <div class="w-full py-20 bg-gradient-to-r from-pink-500 to-orange-500 text-center">
        <h2 class="text-2xl md:text-4xl font-bold text-white mb-6">Exactly what you were looking for?<br>Join now and happy studying!</h2>
        <button class="bg-white text-pink-500 font-semibold py-2 px-4 rounded-full shadow-md hover:bg-gray-100 transition duration-300">Study Together now</button>
    </div>




</body>
</html>