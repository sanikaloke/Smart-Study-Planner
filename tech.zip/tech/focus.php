<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Focus Mode - Pomodoro Timer</title>
    <link rel="stylesheet" href="styles.css">
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            text-align: center;
            background: linear-gradient(to right, #ff9a9e, #fad0c4);
            color: white;
            margin: 0;
            padding: 0;
        }
        .container {
            max-width: 500px;
            margin: auto;
            padding: 40px;
            background: rgba(0, 0, 0, 0.7);
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.3);
            margin-top: 100px;
        }
        h1 {
            font-size: 2em;
        }
        .timer {
            font-size: 3em;
            margin: 20px 0;
        }
        .buttons button {
            padding: 10px 20px;
            font-size: 1.2em;
            margin: 5px;
            border: none;
            cursor: pointer;
            border-radius: 5px;
            transition: 0.3s;
        }
        .start { background: green; color: white; }
        .pause { background: orange; color: white; }
        .reset { background: red; color: white; }
        .buttons button:hover { opacity: 0.8; }
        .input-section {
            margin-bottom: 20px;
        }
        .input-section input {
            padding: 10px;
            font-size: 1em;
            border-radius: 5px;
            border: none;
            text-align: center;
            width: 60px;
            margin: 5px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>⏳ Focus Mode - Pomodoro Timer</h1>
        <p>Stay focused with timed study sessions.</p>
        <div class="input-section">
            <label for="hourInput">Hours: </label>
            <input type="number" id="hourInput" value="0" min="0">
            <label for="minuteInput">Minutes: </label>
            <input type="number" id="minuteInput" value="25" min="0">
            <button onclick="setTimer()">Set</button>
        </div>
        <div class="timer" id="timer">00:25:00</div>
        <div class="buttons">
            <button class="start" onclick="startTimer()">Start</button>
            <button class="pause" onclick="pauseTimer()">Pause</button>
            <button class="reset" onclick="resetTimer()">Reset</button>
        </div>
    </div>
    
    <script>
        let timer;
        let timeLeft = 1500;
        let isRunning = false;

        function setTimer() {
            let inputHours = document.getElementById('hourInput').value;
            let inputMinutes = document.getElementById('minuteInput').value;
            timeLeft = (parseInt(inputHours) * 3600) + (parseInt(inputMinutes) * 60);
            updateDisplay();
        }

        function startTimer() {
            if (!isRunning) {
                isRunning = true;
                timer = setInterval(() => {
                    if (timeLeft > 0) {
                        timeLeft--;
                        updateDisplay();
                    } else {
                        clearInterval(timer);
                        alert("Time's up! Take a break.");
                        isRunning = false;
                    }
                }, 1000);
            }
        }

        function pauseTimer() {
            clearInterval(timer);
            isRunning = false;
        }

        function resetTimer() {
            clearInterval(timer);
            let inputHours = document.getElementById('hourInput').value;
            let inputMinutes = document.getElementById('minuteInput').value;
            timeLeft = (parseInt(inputHours) * 3600) + (parseInt(inputMinutes) * 60);
            updateDisplay();
            isRunning = false;
        }

        function updateDisplay() {
            let hours = Math.floor(timeLeft / 3600);
            let minutes = Math.floor((timeLeft % 3600) / 60);
            let seconds = timeLeft % 60;
            document.getElementById("timer").innerText = 
                ${hours < 10 ? '0' : ''}${hours}:${minutes < 10 ? '0' : ''}${minutes}:${seconds < 10 ? '0' : ''}${seconds};
        }
    </script>
</body>
</html>c