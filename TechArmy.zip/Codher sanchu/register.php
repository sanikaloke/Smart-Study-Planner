<?php
//include "db.php"; // Include the database connection

//$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);
    $confirm_password = trim($_POST['confirm_password']);

    // Validate input fields
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $message = "<p class='error'>Invalid email format!</p>";
    } elseif (strlen($password) < 6) {
        $message = "<p class='error'>Password must be at least 6 characters!</p>";
    } elseif ($password !== $confirm_password) {
        $message = "<p class='error'>Passwords do not match!</p>";
    } else {
        // Hash the password for security
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);

        // Check if email already exists
        $stmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows > 0) {
            $message = "<p class='error'>Email already registered!</p>";
        } else {
            // Insert user into database
            $stmt = $conn->prepare("INSERT INTO users (email, password) VALUES (?, ?)");
            $stmt->bind_param("ss", $email, $hashed_password);

            if ($stmt->execute()) {
                $message = "<p class='success'>Registration successful! <a href='login.php'>Login here</a></p>";
            } else {
                $message = "<p class='error'>Something went wrong. Try again!</p>";
            }
        }
        $stmt->close();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register</title>
    <link rel="stylesheet" href="login.css">
</head>
<body>
    <div class="container">
        <div class="form-box">
            <h2>Register</h2>
            

            <form method="POST" action="">
                <label>Email Address</label>
                <input type="email" name="email" placeholder="you@example.com" required>

                <label>Password</label>
                <input type="password" name="password" placeholder="Enter at least 6 characters" required>

                <label>Confirm Password</label>
                <input type="password" name="confirm_password" placeholder="Re-enter your password" required>

                <button type="submit">REGISTER</button>
                <p>Already have an account? <a href="login.php">Login</a></p>
            </form>

            <?php echo $message; ?>
        </div>

        <div class="illustration">
            <img src="login.jpg" alt="Register Illustration">
        </div>
    </div>
</body>
</html>
