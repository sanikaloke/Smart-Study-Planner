<?php
// Store API keys securely (DO NOT hardcode in the script)
$youtubeApiKey = getenv("AIzaSyCKqHifBWu5_GhVYvZZAzTgsq0zUUpMys0"); // Store this in your environment
$openAiApiKey = getenv("AIzaSyCKqHifBWu5_GhVYvZZAzTgsq0zUUpMys0");   // Store this in your environment


function fetchData($url) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    
    $response = curl_exec($ch);
    if (curl_errno($ch)) {
        return "Error: " . curl_error($ch);
    }

    curl_close($ch);
    return $response;
}

function getYouTubeTranscript($videoId, $youtubeApiKey) {
    $url = "https://www.googleapis.com/youtube/v3/captions?part=snippet&videoId={$videoId}&key={$youtubeApiKey}";
    $response = fetchData($url);
    
    if (strpos($response, "Error") !== false) {
        return "Error: API request failed.";
    }

    $data = json_decode($response, true);

    if (isset($data['error'])) {
        return "Error: " . $data['error']['message'];
    }

    if (empty($data['items'])) {
        return "No transcript available.";
    }

    return "Captions exist, but need OAuth to fetch.";
}

function generateFlashcards($text, $openAiApiKey) {
    $data = [
        "model" => "gpt-4",
        "messages" => [["role" => "user", "content" => "Convert this into flashcards: $text"]],
        "temperature" => 0.7
    ];

    $ch = curl_init("https://api.openai.com/v1/chat/completions");
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        "Authorization: Bearer $openAiApiKey",
        "Content-Type: application/json"
    ]);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

    $response = curl_exec($ch);
    if (curl_errno($ch)) {
        return "Error: " . curl_error($ch);
    }
    curl_close($ch);

    return json_decode($response, true);
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    header("Content-Type: application/json");
    $videoUrl = $_POST['videoUrl'] ?? '';

    // Improved regex for YouTube video ID extraction
    if (!preg_match('/(?:v=|\/embed\/|youtu\.be\/|\/e\/|watch\?v=|\/videos\/)([a-zA-Z0-9_-]{11})/', $videoUrl, $matches)) {
        echo json_encode(["error" => "Invalid YouTube URL"]);
        exit;
    }
}
?>